package n1ex2;

import java.util.*;

public class GenericMethods {
	/**
	 * M�tode que rep tres par�metres de qualsevol tipus i n'imprimeix el tipus de
	 * cadascun per consola.
	 * 
	 * @param <T>
	 * @param <D>
	 * @param <E>
	 * @param t
	 * @param d
	 * @param e
	 */
	public <T, D, E> void f(T t, D d, E e) {
		System.out.println(t.getClass().getSimpleName());
		System.out.println(d.getClass().getSimpleName());
		System.out.println(e.getClass().getSimpleName() + "\n");
	}

	public static void main(String[] args) {
		GenericMethods gen = new GenericMethods();
		/**
		 * cridem el m�tode de la classe amb diferents par�metres i comprovem que s�n
		 * acceptats
		 */
		gen.f('C', "hola", 3);
		gen.f(5L, false, new HashSet<>());
		gen.f(3.2, new ArrayList<>(), new GenericMethods());
	}
}
