package n1ex1;

import java.util.ArrayList;

public class Test {
	public static void main(String[] arg) {
		// inicialitzem la classe amb els tres objectes
		Contenidora contenidora = new Contenidora("java", "php", "c++");
		System.out.println("Contingut inicial:");
		imprimir(contenidora.llista);

		// provem el m�tode per extreure-hi elements
		contenidora.extreure(0);
		System.out.println("Esborrem un valor");
		imprimir(contenidora.llista);

		// provem el m�tode per posar-hi elements
		System.out.println("Afegim un valor:");
		contenidora.emmagatzemar("c#");
		imprimir(contenidora.llista);

	}

	static public void imprimir(ArrayList<String> al) {
		for (String string : al) {
			System.out.println(string);
		}
		System.out.println();
	}
}
