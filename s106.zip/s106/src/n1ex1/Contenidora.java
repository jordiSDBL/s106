package n1ex1;

import java.util.ArrayList;

public class Contenidora {
	// atributs
	ArrayList<String> llista;

	/**
	 * Hi passem per par�metres els tres objectes iguals i incialitzem l'arraylist
	 * per gestionar posar-hi o treure-hi amb els m�todes de la classe
	 * 
	 * @param str1
	 * @param str2
	 * @param str3
	 */

	public Contenidora(String str1, String str2, String str3) {
		this.llista = new ArrayList<>(3);
		this.llista.add(str1);
		this.llista.add(str2);
		this.llista.add(str3);
	}

	/**
	 * Per afegir elements
	 * 
	 * @param str
	 */
	public void emmagatzemar(String str) {
		this.llista.add(str);
	}

	/**
	 * Per esborrar elements
	 * 
	 * @param i
	 */
	public void extreure(int i) {
		this.llista.remove(i);
	}
}
