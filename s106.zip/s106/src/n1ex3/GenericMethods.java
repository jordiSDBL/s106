package n1ex3;

import java.util.HashSet;

public class GenericMethods {
	/**
	 * M�tode que rep dos par�metres de qualsevol tipus i un de fixe i n'imprimeix
	 * el tipus de cadascun per consola.
	 * 
	 * @param <T>
	 * @param <E>
	 * @param t
	 * @param str
	 * @param e
	 */
	public <T, E> void f(T t, String str, E e) {
		System.out.println(t.getClass().getSimpleName());
		System.out.println(str.getClass().getSimpleName());
		System.out.println(e.getClass().getSimpleName() + "\n");
	}

	public static void main(String[] args) {
		GenericMethods gen = new GenericMethods();
		/**
		 * cridem el m�tode de la classe amb diferents par�metres i comprovem que s�n
		 * acceptats
		 */
		gen.f('C', "hola", 3);
		gen.f(5L, "str1", new HashSet<>());
		gen.f(3.2, "str2", new GenericMethods());
	}
}
