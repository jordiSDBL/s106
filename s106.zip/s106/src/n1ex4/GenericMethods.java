package n1ex4;

import java.util.*;

public class GenericMethods {
	/**
	 * M�tode que rep un nombre indeterminat de par�metres de qualsevol tipus i
	 * n'imprimeix per consola el tipus
	 * 
	 * @param <T>
	 * @param t
	 */
	@SuppressWarnings("unchecked")
	public <T> void f(T... t) {
		for (int i = 0; i < t.length; i++) {
			System.out.print("Par�metre " + (i + 1) + " de " + (t.length) + ": ");
			System.out.println(t[i].getClass().getSimpleName() + ".");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		GenericMethods gen = new GenericMethods();
		/**
		 * cridem el m�tode de la classe amb diferent tipus i quantitats de par�metres i
		 * comprovem que s�n acceptats
		 */
		gen.f(2, "3", new ArrayList<Boolean>());
		gen.f('A', new LinkedList<String>());
		gen.f(5L, 3.5, new Object(), false);
	}
}
